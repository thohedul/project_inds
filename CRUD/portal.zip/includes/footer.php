<!-- Footer -->
<section id="footer">
    <div class="footerTop">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="footerlogo">
                        <a href="#" title="php97">
                                    <img src="assets/images/logo-php97.png" alt="php97" />
                                </a>
                        <div class="footercontent">
                            <p>As a non-profit organization we rely on 
                                To donate with your credit card via PayPal please click the button below.</p>
                            
                             <p>As a non-profit organization we rely.</p>
                        </div>
                    </div>
                </div>
                
                 <div class="col-lg-4">
                     <div class="footercol">
                         <h3>Quick Links</h3>
                         <ul class="list-unstyled quick-links">
						<li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>Home</a></li>
						<li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>About</a></li>
						<li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>FAQ</a></li>
						<li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>Get Started</a></li>
						<li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>Videos</a></li>
					</ul>
                     </div>
                </div>
                 <div class="col-lg-4">
                    <div class="footercol">
                         <h3>Location</h3>
                         <div class="map">
                             <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7303.974922601893!2d90.36339262226198!3d23.747826538362318!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755bf4e27d3d0eb%3A0xa1bf0ba0f9bbcb5d!2sSankar+Bus+Stop!5e0!3m2!1sen!2sbd!4v1553170701718" width="330" height="250" frameborder="0" style="border:0" allowfullscreen></iframe>
                         </div>
                     </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footerBottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <p>&copy; php 97 2019. Designed and Developed by PHP97.</p>
                </div>
                <div class="col-lg-6">
                    <ul class="social-network social-circle text-right">
                        <?php if($rss!=""){?>
                        <li><a href="<?php echo $rss;?>" class="icoRss" title="Rss"><i class="fa fa-rss"></i></a></li>
                        <?php } ?>
                        <?php if($facebook!=""){?>
                        <li><a href="<?php echo $facebook;?>" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                        <?php } ?>
                        <?php if($twitter!=""){?>
                        <li><a href="<?php echo $twitter;?>" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                        <?php } ?>
                        <?php if($linkedin!=""){?>
                        <li><a href="<?php echo $linkedin;?>" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
                        <?php } ?>
                        <?php if($google!=""){?>
                        <li><a href="<?php echo $google;?>" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
                        <?php } ?>
                    </ul>				
                </div>
            </div>
        </div>
    </div>
</section>
 <!-- Footer -->
        <script src="assets/js/bootstrap.min.js" type="text/javascript" ></script>
        <script src="assets/js/jquery.ticker.js" type="text/javascript" ></script>
        <script src="assets/js/wow.min.js" type="text/javascript" ></script>
        <script src="assets/js/jquery.prettyPhoto.js" type="text/javascript" ></script>
        <script src="assets/js/owl.carousel.min.js" type="text/javascript" ></script>
        
        <script src="assets/js/scripts.js" type="text/javascript" ></script>

    </body>
</html>