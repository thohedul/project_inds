<?php include('./includes/header.php') ;?>
        <?php include('./slider.php') ;?>
        <!-- Slider End -->

        <!-- Donate Start --> 
        <section id="donate">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="donatePic  wow fadeInLeft" data-wow-delay="300">
                            <img src="assets/images/donate-dog.jpg" alt="There are many ways you can help� " />
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="donatecontent wow fadeInRight" data-wow-delay="300">
                            <h3><?php echo $donate[0]['page_title']; ?></h3>
                            <p><?php //echo $donate[0]['page_description'];
                            if(strlen($donate[0]['page_description']) > 300){
                              echo substr($donate[0]['page_description'], 0 ,300). "...";
                          }
                            ?></p>
                            <button type="button" class="btn btn-warning btn-lg btn-oranged">Donate</button>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Donate End -->

<section id="about">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <h2 class="sectionTitle">About Us</h2>
                        <div class="divider wow fadeInUp" data-wow-delay="600"></div>
                    </div>
                </div>
                <div class="row">
                   
                    <div class="col-lg-6">
                        <div class="aboutcontent wow fadeInRight" data-wow-delay="300">
                            
                            <p> Any amount you can donate is always appreciated.  You can also purchase Friends items from our store.  To donate with your credit card via PayPal please click the button below.</p>
                            <p>As a non-profit organization we rely on 
                                To donate with your credit card via PayPal please click the button below.</p>
                            <button type="button" class="btn btn-warning btn-lg btn-oranged">Donate</button>
                        </div>
                    </div>
                     <div class="col-lg-6">
                        <div class="donatePic  wow fadeInLeft" data-wow-delay="300">
                            <img src="assets/images/donate-dog.jpg" alt="There are many ways you can help� " />
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        
  <!-- Gallery Start -->
  <section id="gallery">
            <div class="container ">
                <div class="row">
                    <div class="col-lg-12">
                        <h2 class="sectionTitle">Gallery</h2>
                        <div class="divider wow fadeInUp" data-wow-delay="600"></div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3">
                        <a href="assets/images/home_2.jpg" rel="prettyPhoto[gallery1]">
                            <img class="img-thumbnail" src="assets/images/home_2.jpg" alt="There are many ways you can help� " />
                        </a>
                    </div>
                     <div class="col-lg-3">
                        <a href="assets/images/home_3.jpg" rel="prettyPhoto[gallery1]">
                            <img class="img-thumbnail" src="assets/images/home_3.jpg" alt="There are many ways you can help� " />
                        </a>
                    </div>
                    <div class="col-lg-3">
                        <a href="assets/images/home_2.jpg" rel="prettyPhoto[gallery1]">
                            <img class="img-thumbnail" src="assets/images/home_2.jpg" alt="There are many ways you can help� " />
                        </a>
                    </div>
                    <div class="col-lg-3">
                        <a href="assets/images/home_3.jpg" rel="prettyPhoto[gallery1]">
                            <img class="img-thumbnail" src="assets/images/home_3.jpg" alt="There are many ways you can help� " />
                        </a>
                    </div>
                </div>
                <div class="empty20 clear"></div>
                <div class="row">
                    <div class="col-lg-3">
                        <a href="assets/images/home_2.jpg" rel="prettyPhoto[gallery2]">
                            <img class="img-thumbnail" src="assets/images/home_2.jpg" alt="There are many ways you can help� " />
                        </a>
                    </div>
                     <div class="col-lg-3">
                        <a href="assets/images/home_2.jpg" rel="prettyPhoto[gallery2]">
                            <img class="img-thumbnail" src="assets/images/home_2.jpg" alt="There are many ways you can help� " />
                        </a>
                    </div>
                    <div class="col-lg-3">
                        <a href="assets/images/home_2.jpg" rel="prettyPhoto[gallery2]">
                            <img class="img-thumbnail" src="assets/images/home_2.jpg" alt="There are many ways you can help� " />
                        </a>
                    </div>
                     <div class="col-lg-3">
                        <a href="assets/images/home_2.jpg" rel="prettyPhoto[gallery2]">
                            <img class="img-thumbnail" src="assets/images/home_2.jpg" alt="There are many ways you can help� " />
                        </a>
                    </div>
                </div>
            </div>
        </section>
  <!-- Gallery end -->
        
        <section id="about2">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <h2 class="sectionTitle whitetext">Call To Us</h2>
                        <div class="dividerwhite wow fadeInUp" data-wow-delay="600"></div>
                    </div>
                </div>
                <div class="row">
                   
                    
                     <div class="col-lg-6">
                        <img src="assets/images/donate-dog.jpg" alt="There are many ways you can help� " />
                    </div>
                    <div class="col-lg-6">
                        <div class="aboutcontent wow fadeInRight" data-wow-delay="300">
                            <div class="empty40"></div>
                            <form action="/action_page.php">
  <div class="form-group whitetext">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" id="email">
  </div>
  <div class="form-group whitetext">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" id="pwd">
  </div>
  <div class="form-group form-check">
    <label class="form-check-label whitetext">
      <input class="form-check-input " type="checkbox"> Remember me
    </label>
  </div>
  <button type="submit" class="btn btn-warning btn-lg btn-oranged borderr90">Submit</button>
</form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
  <!-- Gallery Start -->
  <section id="news">
            <div class="container ">
                <div class="row">
                    <div class="col-lg-12">
                        <h2 class="sectionTitle">News and Events</h2>
                        <div class="divider wow fadeInUp" data-wow-delay="600"></div>
                    </div>
                </div>
                <div class="owl-carousel owl-theme">
                    <?php
                        foreach ($posts as $post){
                    ?>
                    <div class="">
                        <a href="./admin/uploads/<?php echo $post['post_image']?>" rel="prettyPhoto[gallery1]">
                            <img class="img-thumbnail" src="./admin/uploads/<?php echo  $post['post_image']?>" alt="<?php $post['post_title']?>" />
                        </a>
                        <div class="news">
                            <h4><?php echo $post['post_title']?></h4>
                            <p>Category Name : 
                                <?php
                                $catname = $frontendobj->selectcatname($post['postcat_id']);
                      
                      ?>
                                <a href="category.php?cat_id=<?php echo $post['postcat_id']; ?>"><?php echo $catname; ?></a></p>
                            <div class="newsdes" style="margin-bottom: 10px">
                                <?php 
                                       if(strlen($post['post_description']) > 200){
                              echo substr($post['post_description'], 0 ,200). "...";
                          } 
                                        
                                        ?>
                                
                            </div>
                            <a class="btn btn-info btn-sm" href="post_details.php?pid=<?php echo $post['post_id'];?>">Read More</a>
                        </div>
                    </div>
                        <?php } ?>
                </div>
                
            </div>
        </section>
  <!-- Gallery end -->      
<?php include('./includes/footer.php') ;?>